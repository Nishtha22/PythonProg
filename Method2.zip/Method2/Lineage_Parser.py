"""
Custom JSON Parser for Lineage-Based View Definitions
Handles the specific JSON structure with columns, joins, filters, and alias_map
"""

import json
from typing import Dict, List, Any


class LineageViewParser:
    """
    Parses lineage-based view JSON structure and reconstructs SQL-like representation
    for similarity analysis
    """
    
    def __init__(self):
        self.parsed_count = 0
        self.error_count = 0
    
    def parse_view_json(self, json_string: str) -> Dict[str, Any]:
        """
        Parse the lineage-based JSON and extract components
        
        Args:
            json_string: JSON string containing view definition
            
        Returns:
            Dictionary with parsed components
        """
        try:
            # Parse JSON
            if isinstance(json_string, str):
                data = json.loads(json_string)
            else:
                data = json_string
            
            # Extract components
            parsed = {
                'view_name': data.get('view_name', ''),
                'columns': [],
                'column_expressions': [],
                'lineage_tables': set(),
                'lineage_columns': set(),
                'joins': [],
                'join_tables': set(),
                'join_conditions': [],
                'filters': [],
                'aliases': data.get('lineage', {}).get('alias_map', {}),
                'raw_structure': data
            }
            
            lineage = data.get('lineage', {})
            
            # Parse columns
            columns = lineage.get('columns', [])
            has_wildcard = False
            
            for col in columns:
                if isinstance(col, dict):
                    col_name = col.get('column_name', '')
                    expression = col.get('expression', '')
                    col_lineage = col.get('lineage', [])
                    
                    # Handle wildcard column
                    if col_name == '*':
                        has_wildcard = True
                        parsed['columns'].append('*')
                    elif col_name:
                        parsed['columns'].append(col_name)
                    
                    if expression and expression != '*':
                        parsed['column_expressions'].append(expression)
                    
                    # Extract lineage references (e.g., "table1.columnName")
                    for lineage_ref in col_lineage:
                        if isinstance(lineage_ref, str) and '.' in lineage_ref:
                            table, column = lineage_ref.split('.', 1)
                            parsed['lineage_tables'].add(table)
                            # For wildcard, the column might be '*' too
                            if column != '*':
                                parsed['lineage_columns'].add(column)
            
            parsed['has_wildcard'] = has_wildcard
            
            # Parse joins
            joins = lineage.get('joins', [])
            for join in joins:
                if isinstance(join, dict):
                    join_type = join.get('type', 'inner')
                    join_table = join.get('table', '')
                    join_condition = join.get('condition', '')
                    
                    parsed['joins'].append({
                        'type': join_type if join_type else 'inner',
                        'table': join_table,
                        'condition': join_condition
                    })
                    
                    if join_table:
                        parsed['join_tables'].add(join_table)
                    if join_condition:
                        parsed['join_conditions'].append(join_condition)
            
            # Parse filters
            filters = lineage.get('filters', [])
            parsed['filters'] = filters if isinstance(filters, list) else []
            
            self.parsed_count += 1
            return parsed
            
        except Exception as e:
            self.error_count += 1
            print(f"Warning: Error parsing JSON: {e}")
            return {
                'view_name': '',
                'columns': [],
                'column_expressions': [],
                'lineage_tables': set(),
                'lineage_columns': set(),
                'joins': [],
                'join_tables': set(),
                'join_conditions': [],
                'filters': [],
                'aliases': {},
                'raw_structure': {}
            }
    
    def reconstruct_sql_representation(self, parsed: Dict[str, Any]) -> str:
        """
        Reconstruct a SQL-like text representation from parsed components
        This representation will be used for similarity analysis
        
        Args:
            parsed: Parsed view components
            
        Returns:
            SQL-like text representation
        """
        parts = []
        
        # SELECT clause with columns and expressions
        if parsed['columns'] or parsed['column_expressions']:
            select_items = []
            
            # Check if there's a wildcard
            if '*' in parsed['columns']:
                select_items.append('*')
                # Add non-wildcard columns if any
                non_wildcard_cols = [c for c in parsed['columns'] if c != '*']
                select_items.extend(non_wildcard_cols)
            else:
                # Add column names
                select_items.extend(parsed['columns'])
            
            # Add expressions (that aren't wildcards)
            select_items.extend([e for e in parsed['column_expressions'] if e != '*'])
            
            if select_items:
                parts.append(f"SELECT {', '.join(select_items)}")
            else:
                parts.append("SELECT *")
        else:
            parts.append("SELECT *")
        
        # FROM clause with lineage tables and aliases
        all_tables = parsed['lineage_tables'].union(parsed['join_tables'])
        
        if all_tables:
            # Resolve aliases
            resolved_tables = []
            for table in all_tables:
                # Check if table is an alias
                if table in parsed['aliases']:
                    real_table = parsed['aliases'][table]
                    resolved_tables.append(f"{real_table} AS {table}")
                else:
                    resolved_tables.append(table)
            
            if resolved_tables:
                parts.append(f"FROM {resolved_tables[0]}")
        
        # JOIN clauses
        for join in parsed['joins']:
            join_type = join['type'].upper() if join['type'] else 'INNER'
            join_table = join['table']
            join_condition = join['condition']
            
            # Resolve alias for join table
            if join_table in parsed['aliases']:
                real_table = parsed['aliases'][join_table]
                join_clause = f"{join_type} JOIN {real_table} AS {join_table}"
            else:
                join_clause = f"{join_type} JOIN {join_table}"
            
            if join_condition:
                join_clause += f" ON {join_condition}"
            
            parts.append(join_clause)
        
        # WHERE clause with filters
        if parsed['filters']:
            filter_strs = [str(f) for f in parsed['filters']]
            parts.append(f"WHERE {' AND '.join(filter_strs)}")
        
        # Add referenced columns as comments for additional context
        if parsed['lineage_columns']:
            column_context = f"-- Referenced columns: {', '.join(sorted(parsed['lineage_columns']))}"
            parts.append(column_context)
        
        return '\n'.join(parts)
    
    def create_structural_features(self, parsed: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract structural features for similarity comparison
        
        Args:
            parsed: Parsed view components
            
        Returns:
            Dictionary of structural features
        """
        # Resolve all table aliases to actual names
        resolved_tables = set()
        for table in parsed['lineage_tables'].union(parsed['join_tables']):
            if table in parsed['aliases']:
                resolved_tables.add(parsed['aliases'][table])
            else:
                resolved_tables.add(table)
        
        # Determine join types
        join_types = set()
        for join in parsed['joins']:
            join_type = join.get('type', 'inner')
            if join_type:
                join_types.add(join_type.lower())
            else:
                join_types.add('inner')
        
        return {
            'tables': resolved_tables,
            'columns': set(parsed['columns']) - {'*'},  # Exclude wildcard from column set
            'lineage_columns': parsed['lineage_columns'],
            'joins': join_types,
            'aggregates': set(),  # Not present in this structure
            'has_where': len(parsed['filters']) > 0,
            'has_group_by': False,  # Not present in this structure
            'has_order_by': False,  # Not present in this structure
            'num_columns': len([c for c in parsed['columns'] if c != '*']),  # Don't count wildcard
            'num_joins': len(parsed['joins']),
            'num_filters': len(parsed['filters']),
            'has_expressions': len(parsed['column_expressions']) > 0,
            'has_wildcard': parsed.get('has_wildcard', False)  # Track if SELECT * is used
        }
    
    def parse_and_reconstruct(self, json_string: str) -> tuple:
        """
        Parse JSON and return both SQL representation and structural features
        
        Args:
            json_string: JSON string containing view definition
            
        Returns:
            Tuple of (sql_text, structural_features, parsed_components)
        """
        parsed = self.parse_view_json(json_string)
        sql_text = self.reconstruct_sql_representation(parsed)
        features = self.create_structural_features(parsed)
        
        return sql_text, features, parsed
    
    def get_statistics(self) -> Dict[str, int]:
        """Get parsing statistics"""
        return {
            'parsed_successfully': self.parsed_count,
            'parse_errors': self.error_count,
            'total_attempted': self.parsed_count + self.error_count
        }


def test_parser():
    """Test the parser with sample data"""
    
    # Test case 1: Regular columns
    sample_json_1 = {
        "view_name": "customer_orders_view",
        "lineage": {
            "columns": [
                {
                    "column_name": "customer_id",
                    "expression": "c.customer_id",
                    "lineage": ["customers.customer_id"]
                },
                {
                    "column_name": "order_total",
                    "expression": "SUM(o.amount)",
                    "lineage": ["orders.amount"]
                },
                {
                    "column_name": "customer_name",
                    "expression": "c.name",
                    "lineage": ["customers.name"]
                }
            ],
            "joins": [
                {
                    "type": "inner",
                    "table": "orders",
                    "condition": "customers.customer_id = orders.customer_id"
                }
            ],
            "filters": ["customers.status = 'active'", "orders.date > '2024-01-01'"],
            "alias_map": {
                "c": "customers",
                "o": "orders"
            }
        }
    }
    
    # Test case 2: With wildcard column
    sample_json_2 = {
        "view_name": "all_customers_view",
        "lineage": {
            "columns": [
                {
                    "column_name": "*",
                    "expression": "*",
                    "lineage": ["customers.*"]
                }
            ],
            "joins": [],
            "filters": ["customers.active = true"],
            "alias_map": {
                "c": "customers"
            }
        }
    }
    
    # Test case 3: Wildcard with additional columns
    sample_json_3 = {
        "view_name": "customers_with_total",
        "lineage": {
            "columns": [
                {
                    "column_name": "*",
                    "expression": "*",
                    "lineage": ["customers.*"]
                },
                {
                    "column_name": "order_count",
                    "expression": "COUNT(o.order_id)",
                    "lineage": ["orders.order_id"]
                }
            ],
            "joins": [
                {
                    "type": "left",
                    "table": "orders",
                    "condition": "customers.id = orders.customer_id"
                }
            ],
            "filters": [],
            "alias_map": {
                "c": "customers",
                "o": "orders"
            }
        }
    }
    
    parser = LineageViewParser()
    
    print("=" * 80)
    print("LINEAGE VIEW PARSER TEST")
    print("=" * 80)
    
    # Test all cases
    test_cases = [
        ("Regular Columns", sample_json_1),
        ("Wildcard Only", sample_json_2),
        ("Wildcard + Additional Columns", sample_json_3)
    ]
    
    for test_name, sample_json in test_cases:
        print(f"\n{'=' * 80}")
        print(f"TEST: {test_name}")
        print(f"{'=' * 80}")
        
        sql_text, features, parsed = parser.parse_and_reconstruct(json.dumps(sample_json))
        
        print("\n📄 Original JSON:")
        print(json.dumps(sample_json, indent=2)[:300] + "...")
        
        print("\n🔄 Reconstructed SQL:")
        print(sql_text)
        
        print("\n🏗️ Structural Features:")
        for key, value in features.items():
            print(f"  {key}: {value}")
        
        print("\n📊 Key Parsed Components:")
        print(f"  View Name: {parsed['view_name']}")
        print(f"  Columns: {parsed['columns']}")
        print(f"  Has Wildcard: {parsed.get('has_wildcard', False)}")
        print(f"  Tables: {parsed['lineage_tables'].union(parsed['join_tables'])}")
        print(f"  Joins: {len(parsed['joins'])}")
    
    print("\n" + "=" * 80)
    print("All tests completed!")
    print("=" * 80)


if __name__ == "__main__":
    test_parser()