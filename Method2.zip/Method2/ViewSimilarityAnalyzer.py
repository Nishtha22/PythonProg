"""
SQL View Similarity Analyzer
Efficiently compares 3000-4000 SQL views for similarity without LLMs
Uses TF-IDF vectorization and approximate nearest neighbors for scalability
"""

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import csr_matrix
import json
import re
from typing import List, Dict, Tuple
import time


class SQLViewSimilarityAnalyzer:
    """
    Analyzes similarity between SQL views using multiple methods:
    1. TF-IDF with cosine similarity (fast, scalable)
    2. Structural comparison (tables, columns, joins)
    3. Combined scoring
    """
    
    def __init__(self, similarity_threshold: float = 0.7):
        """
        Initialize the analyzer
        
        Args:
            similarity_threshold: Minimum similarity score (0-1) to consider views similar
        """
        self.similarity_threshold = similarity_threshold
        self.vectorizer = None
        self.tfidf_matrix = None
        self.views_data = []
        
    def preprocess_sql(self, sql_text: str) -> str:
        """
        Preprocess SQL text for better comparison
        - Normalize whitespace
        - Convert to lowercase
        - Remove comments
        - Standardize keywords
        """
        if not sql_text:
            return ""
        
        # Remove single-line comments
        sql_text = re.sub(r'--.*$', '', sql_text, flags=re.MULTILINE)
        # Remove multi-line comments
        sql_text = re.sub(r'/\*.*?\*/', '', sql_text, flags=re.DOTALL)
        # Normalize whitespace
        sql_text = re.sub(r'\s+', ' ', sql_text)
        # Convert to lowercase for consistency
        sql_text = sql_text.lower().strip()
        
        return sql_text
    
    def extract_structural_features(self, sql_text: str) -> Dict:
        """
        Extract structural features from SQL view definition
        - Table names
        - Column names
        - JOIN types
        - WHERE clauses
        - Aggregate functions
        """
        features = {
            'tables': set(),
            'columns': set(),
            'joins': set(),
            'aggregates': set(),
            'has_where': False,
            'has_group_by': False,
            'has_order_by': False
        }
        
        sql_lower = sql_text.lower()
        
        # Extract table names (simple pattern)
        table_pattern = r'from\s+(\[?[\w\.]+\]?)|join\s+(\[?[\w\.]+\]?)'
        tables = re.findall(table_pattern, sql_lower)
        for match in tables:
            table = match[0] if match[0] else match[1]
            if table:
                features['tables'].add(table.strip('[]'))
        
        # Extract column names (simple pattern from SELECT clause)
        select_pattern = r'select\s+(.*?)\s+from'
        select_match = re.search(select_pattern, sql_lower, re.DOTALL)
        if select_match:
            columns_text = select_match.group(1)
            # Split by comma and extract column names
            columns = re.findall(r'(\w+)\s*(?:,|$|as)', columns_text)
            features['columns'].update(columns)
        
        # Detect JOIN types
        if 'inner join' in sql_lower:
            features['joins'].add('inner')
        if 'left join' in sql_lower or 'left outer join' in sql_lower:
            features['joins'].add('left')
        if 'right join' in sql_lower or 'right outer join' in sql_lower:
            features['joins'].add('right')
        if 'full join' in sql_lower or 'full outer join' in sql_lower:
            features['joins'].add('full')
        
        # Detect aggregate functions
        agg_functions = ['sum', 'count', 'avg', 'min', 'max', 'group_concat']
        for func in agg_functions:
            if func + '(' in sql_lower:
                features['aggregates'].add(func)
        
        # Detect clauses
        features['has_where'] = 'where' in sql_lower
        features['has_group_by'] = 'group by' in sql_lower
        features['has_order_by'] = 'order by' in sql_lower
        
        return features
    
    def calculate_structural_similarity(self, features1: Dict, features2: Dict) -> float:
        """
        Calculate structural similarity between two views based on extracted features
        Returns a score between 0 and 1
        """
        scores = []
        
        # Table overlap (weighted heavily)
        if features1['tables'] or features2['tables']:
            table_jaccard = len(features1['tables'] & features2['tables']) / \
                           len(features1['tables'] | features2['tables']) if \
                           len(features1['tables'] | features2['tables']) > 0 else 0
            scores.append(table_jaccard * 3)  # Weight: 3
        
        # Column overlap
        if features1['columns'] or features2['columns']:
            column_jaccard = len(features1['columns'] & features2['columns']) / \
                            len(features1['columns'] | features2['columns']) if \
                            len(features1['columns'] | features2['columns']) > 0 else 0
            scores.append(column_jaccard * 2)  # Weight: 2
        
        # JOIN type overlap
        if features1['joins'] or features2['joins']:
            join_jaccard = len(features1['joins'] & features2['joins']) / \
                          len(features1['joins'] | features2['joins']) if \
                          len(features1['joins'] | features2['joins']) > 0 else 0
            scores.append(join_jaccard * 1.5)  # Weight: 1.5
        
        # Aggregate function overlap
        if features1['aggregates'] or features2['aggregates']:
            agg_jaccard = len(features1['aggregates'] & features2['aggregates']) / \
                         len(features1['aggregates'] | features2['aggregates']) if \
                         len(features1['aggregates'] | features2['aggregates']) > 0 else 0
            scores.append(agg_jaccard * 1)  # Weight: 1
        
        # Clause similarity
        clause_matches = sum([
            features1['has_where'] == features2['has_where'],
            features1['has_group_by'] == features2['has_group_by'],
            features1['has_order_by'] == features2['has_order_by']
        ])
        scores.append((clause_matches / 3) * 0.5)  # Weight: 0.5
        
        # Calculate weighted average
        total_weight = 3 + 2 + 1.5 + 1 + 0.5
        return sum(scores) / total_weight if scores else 0
    
    def load_views_from_dataframe(self, df: pd.DataFrame, view_column: str, 
                                   id_column: str = None, name_column: str = None):
        """
        Load views from a pandas DataFrame
        
        Args:
            df: DataFrame containing the views
            view_column: Name of the column containing SQL view definitions
            id_column: Optional column name for view IDs
            name_column: Optional column name for view names
        """
        print(f"Loading {len(df)} views from DataFrame...")
        
        for idx, row in df.iterrows():
            view_def = row[view_column]
            
            # Handle JSON format if the column contains JSON
            if isinstance(view_def, str) and (view_def.strip().startswith('{') or 
                                             view_def.strip().startswith('[')):
                try:
                    view_data = json.loads(view_def)
                    # Assuming the JSON has a 'definition' or 'view_definition' field
                    sql_text = view_data.get('definition', view_data.get('view_definition', str(view_data)))
                except json.JSONDecodeError:
                    sql_text = view_def
            else:
                sql_text = str(view_def)
            
            view_id = row[id_column] if id_column and id_column in row else idx
            view_name = row[name_column] if name_column and name_column in row else f"view_{idx}"
            
            preprocessed_sql = self.preprocess_sql(sql_text)
            structural_features = self.extract_structural_features(preprocessed_sql)
            
            self.views_data.append({
                'id': view_id,
                'name': view_name,
                'original_sql': sql_text,
                'preprocessed_sql': preprocessed_sql,
                'structural_features': structural_features
            })
        
        print(f"Loaded {len(self.views_data)} views successfully")
    
    def build_tfidf_matrix(self):
        """
        Build TF-IDF matrix from preprocessed SQL views
        This is memory-efficient and fast for 3000-4000 views
        """
        print("Building TF-IDF matrix...")
        start_time = time.time()
        
        # Extract preprocessed SQL texts
        sql_texts = [view['preprocessed_sql'] for view in self.views_data]
        
        # Create TF-IDF vectorizer with SQL-specific tokens
        self.vectorizer = TfidfVectorizer(
            max_features=5000,  # Limit features for memory efficiency
            ngram_range=(1, 3),  # Capture 1-3 word phrases
            min_df=2,  # Ignore very rare terms
            max_df=0.8,  # Ignore very common terms
            token_pattern=r'\b\w+\b',  # Word tokens
            stop_words=None  # Keep SQL keywords
        )
        
        self.tfidf_matrix = self.vectorizer.fit_transform(sql_texts)
        
        elapsed = time.time() - start_time
        print(f"TF-IDF matrix built in {elapsed:.2f}s")
        print(f"Matrix shape: {self.tfidf_matrix.shape}")
        print(f"Matrix sparsity: {(1 - self.tfidf_matrix.nnz / (self.tfidf_matrix.shape[0] * self.tfidf_matrix.shape[1])) * 100:.2f}%")
    
    def find_similar_pairs_efficient(self, top_k: int = 10) -> List[Tuple]:
        """
        Find similar view pairs efficiently using cosine similarity
        For each view, finds top_k most similar views
        
        Args:
            top_k: Number of most similar views to find for each view
            
        Returns:
            List of tuples: (view1_idx, view2_idx, tfidf_similarity, structural_similarity, combined_similarity)
        """
        print(f"\nFinding similar pairs (top {top_k} per view)...")
        start_time = time.time()
        
        similar_pairs = []
        n_views = len(self.views_data)
        
        # Calculate cosine similarity in batches to manage memory
        batch_size = 500
        
        for i in range(0, n_views, batch_size):
            batch_end = min(i + batch_size, n_views)
            print(f"Processing batch {i//batch_size + 1}/{(n_views + batch_size - 1)//batch_size}...")
            
            # Calculate similarity for this batch against all views
            batch_similarities = cosine_similarity(
                self.tfidf_matrix[i:batch_end],
                self.tfidf_matrix
            )
            
            # For each view in batch, find top_k similar views
            for batch_idx, similarities in enumerate(batch_similarities):
                view_idx = i + batch_idx
                
                # Get indices of top_k+1 most similar (including itself)
                top_indices = np.argsort(similarities)[::-1][:top_k + 1]
                
                for similar_idx in top_indices:
                    # Skip self-comparison and already processed pairs
                    if similar_idx <= view_idx:
                        continue
                    
                    tfidf_sim = similarities[similar_idx]
                    
                    # Only process if TF-IDF similarity is above a minimum threshold
                    if tfidf_sim < 0.3:  # Early filtering
                        continue
                    
                    # Calculate structural similarity
                    struct_sim = self.calculate_structural_similarity(
                        self.views_data[view_idx]['structural_features'],
                        self.views_data[similar_idx]['structural_features']
                    )
                    
                    # Combined score (weighted average)
                    combined_sim = (0.6 * tfidf_sim + 0.4 * struct_sim)
                    
                    if combined_sim >= self.similarity_threshold:
                        similar_pairs.append((
                            view_idx,
                            similar_idx,
                            float(tfidf_sim),
                            float(struct_sim),
                            float(combined_sim)
                        ))
        
        elapsed = time.time() - start_time
        print(f"Found {len(similar_pairs)} similar pairs in {elapsed:.2f}s")
        
        # Sort by combined similarity (descending)
        similar_pairs.sort(key=lambda x: x[4], reverse=True)
        
        return similar_pairs
    
    def create_similarity_report(self, similar_pairs: List[Tuple], 
                                output_file: str = 'similarity_report.csv'):
        """
        Create a detailed similarity report
        
        Args:
            similar_pairs: List of similar view pairs
            output_file: Output CSV file path
        """
        print(f"\nCreating similarity report...")
        
        report_data = []
        
        for view1_idx, view2_idx, tfidf_sim, struct_sim, combined_sim in similar_pairs:
            view1 = self.views_data[view1_idx]
            view2 = self.views_data[view2_idx]
            
            report_data.append({
                'view1_id': view1['id'],
                'view1_name': view1['name'],
                'view2_id': view2['id'],
                'view2_name': view2['name'],
                'tfidf_similarity': round(tfidf_sim, 4),
                'structural_similarity': round(struct_sim, 4),
                'combined_similarity': round(combined_sim, 4),
                'common_tables': len(view1['structural_features']['tables'] & 
                                   view2['structural_features']['tables']),
                'common_columns': len(view1['structural_features']['columns'] & 
                                    view2['structural_features']['columns']),
                'view1_sql': view1['original_sql'][:200] + '...',  # Truncate for readability
                'view2_sql': view2['original_sql'][:200] + '...'
            })
        
        report_df = pd.DataFrame(report_data)
        report_df.to_csv(output_file, index=False)
        
        print(f"Similarity report saved to: {output_file}")
        print(f"Total similar pairs: {len(report_data)}")
        
        return report_df
    
    def generate_summary_statistics(self, similar_pairs: List[Tuple]) -> Dict:
        """
        Generate summary statistics about view similarities
        """
        if not similar_pairs:
            return {
                'total_views': len(self.views_data),
                'similar_pairs_found': 0,
                'avg_similarity': 0,
                'max_similarity': 0
            }
        
        similarities = [pair[4] for pair in similar_pairs]  # Combined similarity
        
        # Find views with most similar matches
        view_similarity_counts = {}
        for view1_idx, view2_idx, _, _, _ in similar_pairs:
            view_similarity_counts[view1_idx] = view_similarity_counts.get(view1_idx, 0) + 1
            view_similarity_counts[view2_idx] = view_similarity_counts.get(view2_idx, 0) + 1
        
        top_similar_views = sorted(view_similarity_counts.items(), 
                                   key=lambda x: x[1], reverse=True)[:10]
        
        stats = {
            'total_views': len(self.views_data),
            'similar_pairs_found': len(similar_pairs),
            'avg_similarity': np.mean(similarities),
            'max_similarity': np.max(similarities),
            'min_similarity': np.min(similarities),
            'std_similarity': np.std(similarities),
            'views_with_most_matches': [
                (self.views_data[idx]['name'], count) 
                for idx, count in top_similar_views
            ]
        }
        
        return stats


def main():
    """
    Example usage of the SQLViewSimilarityAnalyzer
    """
    
    # Example: Reading from a Starburst table (using your connection method)
    # Here's a template - adjust based on your actual connection method
    
    print("=" * 80)
    print("SQL View Similarity Analyzer")
    print("=" * 80)
    
    # EXAMPLE 1: If you have the data in a pandas DataFrame
    # df = pd.read_sql_query("SELECT * FROM your_starburst_table", your_connection)
    
    # EXAMPLE 2: Create sample data for demonstration
    sample_data = {
        'view_id': range(1, 11),
        'view_name': [f'sample_view_{i}' for i in range(1, 11)],
        'view_definition': [
            '{"definition": "SELECT a, b, c FROM table1 INNER JOIN table2 ON table1.id = table2.id WHERE a > 10"}',
            '{"definition": "SELECT a, b, c FROM table1 JOIN table2 ON table1.id = table2.id WHERE a > 5"}',
            '{"definition": "SELECT x, y, z FROM table3 LEFT JOIN table4 ON table3.id = table4.id"}',
            '{"definition": "SELECT sum(amount), customer_id FROM orders GROUP BY customer_id"}',
            '{"definition": "SELECT count(*), customer_id FROM orders GROUP BY customer_id"}',
            '{"definition": "SELECT * FROM products WHERE price > 100 ORDER BY price"}',
            '{"definition": "SELECT * FROM products WHERE price > 50 ORDER BY price DESC"}',
            '{"definition": "SELECT a, b FROM table1 WHERE status = \'active\'"}',
            '{"definition": "SELECT a, b FROM table1 WHERE status = \'pending\'"}',
            '{"definition": "SELECT d, e, f FROM table5 FULL OUTER JOIN table6 ON table5.key = table6.key"}',
        ]
    }
    
    df = pd.DataFrame(sample_data)
    
    # Initialize analyzer
    analyzer = SQLViewSimilarityAnalyzer(similarity_threshold=0.5)
    
    # Load views
    analyzer.load_views_from_dataframe(
        df, 
        view_column='view_definition',
        id_column='view_id',
        name_column='view_name'
    )
    
    # Build TF-IDF matrix
    analyzer.build_tfidf_matrix()
    
    # Find similar pairs
    similar_pairs = analyzer.find_similar_pairs_efficient(top_k=5)
    
    # Create report
    report_df = analyzer.create_similarity_report(similar_pairs, 'similarity_report.csv')
    
    # Generate statistics
    stats = analyzer.generate_summary_statistics(similar_pairs)
    
    print("\n" + "=" * 80)
    print("SUMMARY STATISTICS")
    print("=" * 80)
    print(f"Total views analyzed: {stats['total_views']}")
    print(f"Similar pairs found: {stats['similar_pairs_found']}")
    print(f"Average similarity: {stats['avg_similarity']:.4f}")
    print(f"Max similarity: {stats['max_similarity']:.4f}")
    print(f"Min similarity: {stats['min_similarity']:.4f}")
    
    print("\nTop views with most similar matches:")
    for view_name, count in stats['views_with_most_matches'][:5]:
        print(f"  {view_name}: {count} similar views")
    
    print("\n" + "=" * 80)
    print("Analysis complete! Check 'similarity_report.csv' for detailed results.")
    print("=" * 80)


if __name__ == "__main__":
    main()