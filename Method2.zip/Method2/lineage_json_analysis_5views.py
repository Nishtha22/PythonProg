#!/usr/bin/env python3
"""
Standalone Lineage JSON Similarity Analysis (No Starburst Required)
Simple analysis for 5 JSON view definitions.
"""

import json
import pandas as pd
from collections import defaultdict
from typing import Dict, List, Set, Tuple

# ============================================================================
# SAMPLE JSON VIEW DEFINITIONS
# ============================================================================

SAMPLE_VIEWS_JSON = [
    {
        "view_name": "sales.daily_deals",
        "lineage": {
            "columns": [
                {"column_name": "deal_id", "expression": "d.id", "lineage": ["deals.id"]},
                {"column_name": "deal_amount", "expression": "d.amount", "lineage": ["deals.amount"]},
                {"column_name": "customer_name", "expression": "c.name", "lineage": ["customers.name"]},
                {"column_name": "deal_date", "expression": "d.created_date", "lineage": ["deals.created_date"]}
            ],
            "joins": [
                {"type": "INNER", "table": "customers", "condition": "d.customer_id = c.id"}
            ],
            "filters": ["d.status = 'COMPLETED'"],
            "alias_map": {"d": "deals", "c": "customers"}
        }
    },
    {
        "view_name": "sales.deals_summary",
        "lineage": {
            "columns": [
                {"column_name": "deal_id", "expression": "deal_id", "lineage": ["deals.id"]},
                {"column_name": "amount", "expression": "amount", "lineage": ["deals.amount"]},
                {"column_name": "customer_id", "expression": "customer_id", "lineage": ["deals.customer_id"]}
            ],
            "joins": [],
            "filters": ["status IN ('COMPLETED', 'PENDING')"],
            "alias_map": {}
        }
    },
    {
        "view_name": "finance.revenue_stream",
        "lineage": {
            "columns": [
                {"column_name": "*", "expression": "*", "lineage": []}
            ],
            "joins": [],
            "filters": ["amount > 0"],
            "alias_map": {"d": "deals"}
        }
    },
    {
        "view_name": "analytics.customer_transactions",
        "lineage": {
            "columns": [
                {"column_name": "customer_id", "expression": "c.id", "lineage": ["customers.id"]},
                {"column_name": "transaction_count", "expression": "COUNT(*)", "lineage": []},
                {"column_name": "total_spent", "expression": "SUM(d.amount)", "lineage": ["deals.amount"]}
            ],
            "joins": [
                {"type": "INNER", "table": "deals", "condition": "c.id = d.customer_id"}
            ],
            "filters": [],
            "alias_map": {"c": "customers", "d": "deals"}
        }
    },
    {
        "view_name": "reporting.customer_summary",
        "lineage": {
            "columns": [
                {"column_name": "id", "expression": "id", "lineage": ["customers.id"]},
                {"column_name": "name", "expression": "name", "lineage": ["customers.name"]},
                {"column_name": "email", "expression": "email", "lineage": ["customers.email"]}
            ],
            "joins": [],
            "filters": ["active = true"],
            "alias_map": {}
        }
    }
]

# ============================================================================
# LINEAGE SIMILARITY ANALYZER
# ============================================================================

class LineageSimilarityAnalyzer:
    """
    Analyzes similarity between views based on their lineage JSON structure.
    Compares tables, columns, joins, and filters.
    """
    
    def __init__(self, threshold=0.7):
        self.threshold = threshold
    
    def extract_tables(self, view: Dict) -> Set[str]:
        """Extract tables from view lineage"""
        tables = set()
        lineage = view.get('lineage', {})
        
        # From joins
        for join in lineage.get('joins', []):
            if isinstance(join, dict):
                tables.add(join.get('table', ''))
        
        # From alias_map
        alias_map = lineage.get('alias_map', {})
        tables.update(alias_map.values())
        
        # From column lineage
        for col_info in lineage.get('columns', []):
            if isinstance(col_info, dict):
                for upstream in col_info.get('lineage', []):
                    if isinstance(upstream, str) and '.' in upstream:
                        table = upstream.split('.')[0]
                        if table in alias_map:
                            tables.add(alias_map[table])
                        else:
                            tables.add(table)
        
        return tables - {''}
    
    def extract_columns(self, view: Dict) -> Set[str]:
        """Extract columns from view"""
        columns = set()
        lineage = view.get('lineage', {})
        
        for col_info in lineage.get('columns', []):
            if isinstance(col_info, dict):
                col_name = col_info.get('column_name', '')
                if col_name and col_name != '*':
                    columns.add(col_name)
        
        return columns
    
    def extract_joins(self, view: Dict) -> Set[str]:
        """Extract join types from view"""
        joins = set()
        lineage = view.get('lineage', {})
        
        for join in lineage.get('joins', []):
            if isinstance(join, dict):
                joins.add(join.get('type', 'INNER'))
        
        return joins
    
    def has_wildcard(self, view: Dict) -> bool:
        """Check if view has wildcard selection"""
        lineage = view.get('lineage', {})
        for col_info in lineage.get('columns', []):
            if isinstance(col_info, dict):
                if col_info.get('column_name', '').strip() == '*':
                    return True
        return False
    
    def compute_similarity(self, view1: Dict, view2: Dict) -> Dict:
        """
        Compute similarity between two views
        """
        tables1 = self.extract_tables(view1)
        tables2 = self.extract_tables(view2)
        
        columns1 = self.extract_columns(view1)
        columns2 = self.extract_columns(view2)
        
        joins1 = self.extract_joins(view1)
        joins2 = self.extract_joins(view2)
        
        wildcard1 = self.has_wildcard(view1)
        wildcard2 = self.has_wildcard(view2)
        
        # Calculate Jaccard similarities
        table_sim = self._jaccard(tables1, tables2)
        join_sim = self._jaccard(joins1, joins2)
        
        # Column similarity (account for wildcards)
        if wildcard1 or wildcard2:
            if tables1 & tables2:  # Shared tables
                column_sim = 0.9
            else:
                column_sim = 0.0
        else:
            column_sim = self._jaccard(columns1, columns2)
        
        # Number of tables and joins
        table_count_diff = abs(len(tables1) - len(tables2)) / max(len(tables1), len(tables2), 1)
        join_count_sim = 1 - table_count_diff
        
        # Weighted composite
        weights = {
            'table': 0.40,
            'column': 0.35,
            'join': 0.15,
            'join_count': 0.10
        }
        
        overall = (
            table_sim * weights['table'] +
            column_sim * weights['column'] +
            join_sim * weights['join'] +
            join_count_sim * weights['join_count']
        )
        
        return {
            'view1': view1['view_name'],
            'view2': view2['view_name'],
            'overall_similarity': round(overall, 4),
            'table_similarity': round(table_sim, 4),
            'column_similarity': round(column_sim, 4),
            'join_similarity': round(join_sim, 4),
            'common_tables': sorted(list(tables1 & tables2)),
            'common_columns': sorted(list(columns1 & columns2)),
            'tables1': sorted(list(tables1)),
            'tables2': sorted(list(tables2)),
            'has_wildcard1': wildcard1,
            'has_wildcard2': wildcard2,
            'is_redundant': overall >= self.threshold
        }
    
    @staticmethod
    def _jaccard(set1: Set, set2: Set) -> float:
        """Calculate Jaccard similarity"""
        if len(set1 | set2) == 0:
            return 0.0
        return len(set1 & set2) / len(set1 | set2)

# ============================================================================
# MAIN ANALYSIS
# ============================================================================

def print_section(title):
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80)

print_section("LINEAGE JSON SIMILARITY ANALYSIS - 5 VIEWS")

analyzer = LineageSimilarityAnalyzer(threshold=0.70)

# Step 1: Display views
print_section("STEP 1: VIEW DEFINITIONS")

for i, view in enumerate(SAMPLE_VIEWS_JSON, 1):
    view_name = view['view_name']
    tables = analyzer.extract_tables(view)
    columns = analyzer.extract_columns(view)
    joins = analyzer.extract_joins(view)
    wildcard = analyzer.has_wildcard(view)
    
    print(f"\n{i}. {view_name}")
    print(f"   Tables: {sorted(tables)}")
    
    if wildcard:
        print(f"   Columns: {len(columns)} (has wildcard *)")
    else:
        cols_preview = ', '.join(sorted(list(columns)[:3]))
        print(f"   Columns: {len(columns)} ({cols_preview}...)")
    
    print(f"   Joins: {len(joins)} {sorted(joins)}")

# Step 2: Group by tables
print_section("STEP 2: GROUPING BY TABLE SETS")

table_groups = defaultdict(list)
for view in SAMPLE_VIEWS_JSON:
    table_set = frozenset(analyzer.extract_tables(view))
    table_groups[table_set].append(view['view_name'])
    print(f"  {view['view_name']:35s} → {sorted(list(table_set))}")

print(f"\nFound {len(table_groups)} unique table sets")

# Step 3: Compute similarities
print_section("STEP 3: COMPUTING SIMILARITIES WITHIN TABLE GROUPS")

all_results = []
total_comparisons = 0

for table_set, view_names in table_groups.items():
    if len(view_names) < 2:
        print(f"\n  [SKIP] {sorted(list(table_set))}: only {len(view_names)} view")
        continue
    
    print(f"\n  📊 Group: {sorted(list(table_set))} ({len(view_names)} views)")
    
    # Get views in this group
    group_views = [v for v in SAMPLE_VIEWS_JSON if v['view_name'] in view_names]
    
    # Compare pairs
    for i in range(len(group_views)):
        for j in range(i + 1, len(group_views)):
            sim_result = analyzer.compute_similarity(group_views[i], group_views[j])
            total_comparisons += 1
            all_results.append(sim_result)
            
            status = "✓" if sim_result['is_redundant'] else "•"
            print(f"     {status} {sim_result['view1']:30s} ↔ {sim_result['view2']:30s} | Sim: {sim_result['overall_similarity']:.4f}")

# Step 4: Summary
print_section("RESULTS SUMMARY")

if all_results:
    df = pd.DataFrame(all_results)
    df = df.sort_values('overall_similarity', ascending=False)
    
    print(f"\nTotal comparisons: {total_comparisons}")
    print(f"High similarity (≥0.7): {len(df[df['overall_similarity'] >= 0.70])}")
    print(f"Redundant pairs: {len(df[df['is_redundant']])}")
    
    print("\nDetailed Results:")
    print(df[['view1', 'view2', 'overall_similarity', 'table_similarity', 'column_similarity', 'is_redundant']].to_string(index=False))
    
    # Export to Excel
    output_file = '5_views_lineage_analysis.xlsx'
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='All Comparisons', index=False)
        
        redundant_df = df[df['is_redundant']]
        if len(redundant_df) > 0:
            redundant_df.to_excel(writer, sheet_name='Redundant Only', index=False)
        
        print(f"\n✓ Exported to {output_file}")
else:
    print("No comparisons made")

print("\n" + "=" * 80)
print("ANALYSIS COMPLETE")
print("=" * 80)
