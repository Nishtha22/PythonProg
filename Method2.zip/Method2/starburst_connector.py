"""
Starburst Connector for Loading View Lineage Data
Handles DSN configuration and fetching lineage JSON from Starburst
"""

import json
import pyodbc
import pandas as pd
from typing import List, Dict, Optional
from configparser import ConfigParser
import os


class StarburstConnector:
    """
    Connects to Starburst and fetches view definitions with lineage JSON
    """
    
    def __init__(self, config_file: str = 'starburst_config.ini'):
        """
        Initialize Starburst connector from config file
        
        Args:
            config_file: Path to configuration file with DSN and credentials
        """
        self.connection = None
        self.config = self._load_config(config_file)
        self._validate_config()
        
    def _load_config(self, config_file: str) -> Dict[str, str]:
        """
        Load configuration from INI file
        
        Expected format:
        [STARBURST]
        driver = Simba Presto Driver
        host = your-starburst-host.com
        port = 8443
        user = your_username
        password = your_password
        catalog = your_catalog
        schema = your_schema
        ssl = True
        """
        config = ConfigParser()
        
        if not os.path.exists(config_file):
            self._create_sample_config(config_file)
            raise FileNotFoundError(
                f"Config file not found. Sample created at {config_file}. "
                "Please fill in your Starburst connection details."
            )
        
        config.read(config_file)
        return dict(config['STARBURST'])
    
    def _create_sample_config(self, config_file: str):
        """Create a sample configuration file"""
        sample_config = """[STARBURST]
# Starburst Connection Configuration
driver = Simba Presto Driver
host = your-starburst-host.com
port = 8443
user = your_username
password = your_password
catalog = your_catalog
schema = your_schema
ssl = True

# DSN Name (alternative to host/port connection)
dsn = your_dsn_name
"""
        with open(config_file, 'w') as f:
            f.write(sample_config)
    
    def _validate_config(self):
        """Validate required configuration parameters"""
        required_fields = ['user', 'password', 'catalog', 'schema']
        missing = [field for field in required_fields if field not in self.config]
        
        if missing:
            raise ValueError(f"Missing required config fields: {missing}")
    
    def connect(self, use_dsn: bool = False) -> bool:
        """
        Establish connection to Starburst
        
        Args:
            use_dsn: If True, use DSN-based connection; if False, use host/port
            
        Returns:
            True if connection successful, False otherwise
        """
        try:
            if use_dsn and 'dsn' in self.config:
                # DSN-based connection
                connection_string = f"DSN={self.config['dsn']};UID={self.config['user']};PWD={self.config['password']}"
            else:
                # Host/port-based connection (Presto/Trino driver)
                driver = self.config.get('driver', 'Simba Presto Driver')
                host = self.config.get('host')
                port = self.config.get('port', '8443')
                
                connection_string = (
                    f"Driver={{{driver}}};"
                    f"Host={host};"
                    f"Port={port};"
                    f"AuthType=LDAP;"
                    f"UID={self.config['user']};"
                    f"PWD={self.config['password']}"
                )
            
            self.connection = pyodbc.connect(connection_string)
            print("✓ Successfully connected to Starburst")
            return True
            
        except pyodbc.Error as e:
            print(f"✗ Connection failed: {e}")
            return False
    
    def fetch_views_with_lineage(self, 
                                 table_name: str,
                                 view_id_col: str = 'view_id',
                                 view_name_col: str = 'view_name',
                                 lineage_json_col: str = 'lineage_json',
                                 batch_size: int = 500) -> List[Dict]:
        """
        Fetch view definitions with lineage JSON from Starburst
        
        Args:
            table_name: Name of the table containing view metadata (e.g., 'metadata.views')
            view_id_col: Column name for view ID
            view_name_col: Column name for view name
            lineage_json_col: Column name containing lineage JSON
            batch_size: Number of views to fetch per batch
            
        Returns:
            List of view dictionaries with parsed lineage JSON
        """
        if not self.connection:
            raise RuntimeError("Not connected to Starburst. Call connect() first.")
        
        query = f"""
        SELECT 
            {view_id_col} as view_id,
            {view_name_col} as view_name,
            {lineage_json_col} as lineage_json
        FROM {self.config['catalog']}.{self.config['schema']}.{table_name}
        WHERE active = true
        ORDER BY {view_id_col}
        """
        
        print(f"Fetching views from {table_name}...")
        views = []
        
        try:
            cursor = self.connection.cursor()
            cursor.execute(query)
            
            while True:
                rows = cursor.fetchmany(batch_size)
                if not rows:
                    break
                
                for row in rows:
                    try:
                        lineage_data = json.loads(row[2]) if isinstance(row[2], str) else row[2]
                        views.append({
                            'view_id': row[0],
                            'view_name': row[1],
                            'lineage': lineage_data
                        })
                    except json.JSONDecodeError as e:
                        print(f"Warning: Failed to parse lineage JSON for view {row[1]}: {e}")
                
                print(f"  Loaded {len(views)} views so far...")
            
            print(f"✓ Successfully fetched {len(views)} views")
            return views
            
        except pyodbc.Error as e:
            print(f"✗ Query failed: {e}")
            return []
    
    def fetch_views_df(self, 
                       table_name: str,
                       view_id_col: str = 'view_id',
                       view_name_col: str = 'view_name',
                       lineage_json_col: str = 'lineage_json') -> pd.DataFrame:
        """
        Fetch views as a pandas DataFrame
        
        Args:
            table_name: Name of the metadata table
            view_id_col: Column name for view ID
            view_name_col: Column name for view name
            lineage_json_col: Column name containing lineage JSON
            
        Returns:
            pandas DataFrame with view data
        """
        query = f"""
        SELECT 
            {view_id_col} as view_id,
            {view_name_col} as view_name,
            {lineage_json_col} as lineage_json
        FROM {self.config['catalog']}.{self.config['schema']}.{table_name}
        WHERE active = true
        """
        
        try:
            df = pd.read_sql(query, self.connection)
            print(f"✓ Loaded {len(df)} views into DataFrame")
            return df
            
        except Exception as e:
            print(f"✗ Failed to load DataFrame: {e}")
            return pd.DataFrame()
    
    def close(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
            print("Connection closed")
    
    def __enter__(self):
        """Context manager support"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager cleanup"""
        self.close()


def create_config_template():
    """
    Create a template configuration file for the user to fill in
    """
    template = """[STARBURST]
# ============================================================================
# Starburst/Trino Connection Configuration
# ============================================================================

# Connection Method 1: Host-based (recommended for Starburst)
driver = Simba Presto Driver
host = starburst.example.com
port = 8443
ssl = True

# Connection Method 2: DSN (Data Source Name)
# Uncomment below and comment out host/port above if using DSN
# dsn = my_starburst_dsn

# Authentication
user = your_starburst_username
password = your_starburst_password

# Target Database
catalog = your_catalog_name
schema = your_schema_name

# ============================================================================
# Example Table Information
# ============================================================================
# Assuming your metadata table looks like:
#   Table: metadata.views
#   Columns:
#     - view_id (INTEGER): Unique view identifier
#     - view_name (VARCHAR): Fully qualified view name (e.g., 'schema.view_name')
#     - lineage_json (VARCHAR/JSON): JSON with columns, joins, filters, alias_map
#     - active (BOOLEAN): Whether view is currently active
#
# Usage in code:
#   connector.fetch_views_with_lineage('views', active_filter=True)
"""
    return template


# Example usage
if __name__ == "__main__":
    print("=" * 80)
    print("Starburst Connector Example")
    print("=" * 80)
    
    # Step 1: Create config template
    print("\n1. Creating configuration template...")
    template = create_config_template()
    print(template)
    
    # Step 2: Initialize connector (will fail until config is filled)
    print("\n2. To use this connector:")
    print("   - Edit 'starburst_config.ini' with your connection details")
    print("   - Call: connector = StarburstConnector('starburst_config.ini')")
    print("   - Connect: connector.connect()")
    print("   - Fetch: views = connector.fetch_views_with_lineage('metadata.views')")
    
    # Example (commented out - will fail without proper config)
    # try:
    #     with StarburstConnector() as connector:
    #         connector.connect()
    #         views = connector.fetch_views_with_lineage('views')
    #         print(f"Loaded {len(views)} views")
    # except Exception as e:
    #     print(f"Error: {e}")
