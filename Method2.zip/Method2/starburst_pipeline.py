"""
Pipeline: Load views from Starburst → Analyze Similarity → Export Results
Integrates StarburstConnector with LineageSimilarityAnalyzer
"""

import json
from starburst_connector import StarburstConnector
from lineage_json_analysis_5views import LineageSimilarityAnalyzer
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter


class StarburstSimilarityPipeline:
    """
    End-to-end pipeline: Fetch views from Starburst → Compute similarity → Export results
    """
    
    def __init__(self, config_file: str = 'starburst_config.ini'):
        """
        Initialize pipeline with Starburst connection
        
        Args:
            config_file: Path to starburst_config.ini
        """
        self.connector = StarburstConnector(config_file)
        self.analyzer = None
        self.views = []
        self.results = []
        
    def connect_to_starburst(self) -> bool:
        """Connect to Starburst database"""
        print("\n" + "=" * 80)
        print("STEP 1: Connecting to Starburst")
        print("=" * 80)
        return self.connector.connect(use_dsn=False)
    
    def fetch_views_from_starburst(self, 
                                   table_name: str = 'metadata.views',
                                   view_id_col: str = 'view_id',
                                   view_name_col: str = 'view_name',
                                   lineage_json_col: str = 'lineage_json') -> bool:
        """
        Fetch view definitions with lineage JSON from Starburst
        
        Args:
            table_name: Metadata table (e.g., 'metadata.views' or 'starburst_metadata.catalog_tables')
            view_id_col: Column name for view ID
            view_name_col: Column name for view name
            lineage_json_col: Column name containing lineage JSON
            
        Returns:
            True if successful, False otherwise
        """
        print("\n" + "=" * 80)
        print("STEP 2: Fetching Views from Starburst")
        print("=" * 80)
        print(f"Table: {table_name}")
        print(f"  view_id column: {view_id_col}")
        print(f"  view_name column: {view_name_col}")
        print(f"  lineage_json column: {lineage_json_col}")
        
        try:
            self.views = self.connector.fetch_views_with_lineage(
                table_name=table_name,
                view_id_col=view_id_col,
                view_name_col=view_name_col,
                lineage_json_col=lineage_json_col,
                batch_size=500
            )
            
            if not self.views:
                print("✗ No views fetched")
                return False
            
            print(f"✓ Fetched {len(self.views)} views")
            return True
            
        except Exception as e:
            print(f"✗ Error fetching views: {e}")
            return False
    
    def analyze_similarity(self, redundancy_threshold: float = 0.70) -> bool:
        """
        Compute similarity between fetched views
        
        Args:
            redundancy_threshold: Similarity threshold for flagging as redundant
            
        Returns:
            True if analysis successful, False otherwise
        """
        print("\n" + "=" * 80)
        print("STEP 3: Analyzing View Similarity")
        print("=" * 80)
        
        try:
            # Initialize analyzer with fetched views
            self.analyzer = LineageSimilarityAnalyzer(self.views)
            
            # Run similarity analysis
            self.results = self.analyzer.analyze_all()
            
            print(f"✓ Analyzed {len(self.results)} view pairs")
            
            # Count redundant pairs
            redundant = [r for r in self.results if r['is_redundant']]
            print(f"✓ Found {len(redundant)} redundant pairs (similarity >= {redundancy_threshold})")
            
            return True
            
        except Exception as e:
            print(f"✗ Error during analysis: {e}")
            return False
    
    def export_results(self, output_file: str = 'starburst_similarity_results.xlsx'):
        """
        Export similarity results to Excel
        
        Args:
            output_file: Output Excel file path
        """
        print("\n" + "=" * 80)
        print("STEP 4: Exporting Results")
        print("=" * 80)
        
        try:
            # Create workbook
            wb = Workbook()
            ws = wb.active
            ws.title = "All Comparisons"
            
            # Define styles
            header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            header_font = Font(bold=True, color="FFFFFF")
            redundant_fill = PatternFill(start_color="FFE699", end_color="FFE699", fill_type="solid")
            center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
            border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            # Write headers
            headers = [
                'View 1', 'View 2', 'Similarity', 'Table Overlap', 'Column Overlap', 
                'Join Pattern', 'Redundant?'
            ]
            for col, header in enumerate(headers, 1):
                cell = ws.cell(row=1, column=col)
                cell.value = header
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = center_align
                cell.border = border
            
            # Write data rows
            for row_idx, result in enumerate(self.results, 2):
                row_data = [
                    result['view1_name'],
                    result['view2_name'],
                    f"{result['similarity']:.4f}",
                    f"{result['table_overlap']:.4f}",
                    f"{result['column_overlap']:.4f}",
                    f"{result['join_pattern']:.4f}",
                    'YES' if result['is_redundant'] else 'NO'
                ]
                
                for col_idx, value in enumerate(row_data, 1):
                    cell = ws.cell(row=row_idx, column=col_idx)
                    cell.value = value
                    cell.alignment = center_align
                    cell.border = border
                    
                    # Highlight redundant rows
                    if result['is_redundant']:
                        cell.fill = redundant_fill
            
            # Auto-adjust column widths
            for col in range(1, len(headers) + 1):
                ws.column_dimensions[get_column_letter(col)].width = 18
            
            # Create redundant-only sheet
            if any(r['is_redundant'] for r in self.results):
                ws_redundant = wb.create_sheet("Redundant Pairs")
                
                for col, header in enumerate(headers, 1):
                    cell = ws_redundant.cell(row=1, column=col)
                    cell.value = header
                    cell.fill = header_fill
                    cell.font = header_font
                    cell.alignment = center_align
                    cell.border = border
                
                row_idx = 2
                for result in self.results:
                    if result['is_redundant']:
                        row_data = [
                            result['view1_name'],
                            result['view2_name'],
                            f"{result['similarity']:.4f}",
                            f"{result['table_overlap']:.4f}",
                            f"{result['column_overlap']:.4f}",
                            f"{result['join_pattern']:.4f}",
                            'YES'
                        ]
                        
                        for col_idx, value in enumerate(row_data, 1):
                            cell = ws_redundant.cell(row=row_idx, column=col_idx)
                            cell.value = value
                            cell.alignment = center_align
                            cell.border = border
                            cell.fill = redundant_fill
                        
                        row_idx += 1
                
                # Auto-adjust column widths
                for col in range(1, len(headers) + 1):
                    ws_redundant.column_dimensions[get_column_letter(col)].width = 18
            
            # Save workbook
            wb.save(output_file)
            print(f"✓ Results exported to: {output_file}")
            
        except Exception as e:
            print(f"✗ Error exporting results: {e}")
    
    def run(self, 
            table_name: str = 'metadata.views',
            output_file: str = 'starburst_similarity_results.xlsx') -> bool:
        """
        Run complete pipeline: Connect → Fetch → Analyze → Export
        
        Args:
            table_name: Starburst metadata table name
            output_file: Output Excel file
            
        Returns:
            True if pipeline successful, False otherwise
        """
        print("\n" + "#" * 80)
        print("# STARBURST VIEW SIMILARITY PIPELINE")
        print("#" * 80)
        
        try:
            # Step 1: Connect
            if not self.connect_to_starburst():
                return False
            
            # Step 2: Fetch views
            if not self.fetch_views_from_starburst(table_name):
                return False
            
            # Step 3: Analyze
            if not self.analyze_similarity():
                return False
            
            # Step 4: Export
            self.export_results(output_file)
            
            print("\n" + "#" * 80)
            print("# PIPELINE COMPLETE ✓")
            print("#" * 80)
            print(f"Total views analyzed: {len(self.views)}")
            print(f"Total comparisons: {len(self.results)}")
            print(f"Redundant pairs found: {sum(1 for r in self.results if r['is_redundant'])}")
            print(f"Results saved to: {output_file}")
            
            return True
            
        except Exception as e:
            print(f"\n✗ Pipeline failed: {e}")
            return False
        finally:
            self.connector.close()


def main():
    """
    Example usage of the pipeline
    """
    # Initialize pipeline
    pipeline = StarburstSimilarityPipeline(config_file='starburst_config.ini')
    
    # Run pipeline with your table details
    # Customize these parameters based on your Starburst schema:
    success = pipeline.run(
        table_name='metadata.views',  # Change to your actual table
        output_file='starburst_similarity_results.xlsx'
    )
    
    if success:
        print("\n✓ Pipeline completed successfully!")
    else:
        print("\n✗ Pipeline failed. Check configuration and table details.")


if __name__ == "__main__":
    main()
